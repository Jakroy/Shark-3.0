// --------------------------------
// JSON-based CLI solver for web interface
// --------------------------------
#include "../hands/PreflopRange.hh"
#include "../solver/Solver.hh"
#include "../tree/GameTree.hh"
#include "../tree/Nodes.hh"
#include "../trainer/DCFR.hh"
#include <iostream>
#include <fstream>
#include <sstream>
#include <chrono>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
using phevaluator::Card;

int main(int argc, char* argv[]) {
    try {
        // Read JSON from stdin or file
        json input;
        if (argc > 1) {
            std::ifstream file(argv[1]);
            file >> input;
        } else {
            std::cin >> input;
        }

        // Parse input
        std::string hero_range_str = input["hero_range"];
        std::string villain_range_str = input["villain_range"];

        PreflopRange hero_range{hero_range_str};
        PreflopRange villain_range{villain_range_str};

        // Parse board
        std::vector<Card> board;
        for (const auto& card_str : input["board"]) {
            board.push_back(Card{card_str.get<std::string>()});
        }

        int stack = input.value("stack", 100);
        int pot = input.value("pot", 10);
        int min_bet = input.value("min_bet", 2);
        int position = input.value("position", 2); // 1 or 2
        int iterations = input.value("iterations", 100);
        int threads = input.value("threads", 4);
        float all_in_threshold = input.value("all_in_threshold", 0.67);
        bool remove_donk_bets = input.value("remove_donk_bets", true);
        int raise_cap = input.value("raise_cap", 3);

        // Build tree
        auto t_start = std::chrono::high_resolution_clock::now();

        TreeBuilderSettings settings{hero_range, villain_range, position, board, stack, pot, min_bet, all_in_threshold};
        settings.remove_donk_bets = remove_donk_bets;
        settings.raise_cap = raise_cap;

        DCFR::compress_strategy = true;

        PreflopRangeManager prm{hero_range.preflop_combos, villain_range.preflop_combos, board};
        GameTree game_tree{settings};
        std::unique_ptr<Node> root{game_tree.build()};

        auto stats = game_tree.getTreeStats();
        auto t_tree = std::chrono::high_resolution_clock::now();

        // Train
        ParallelDCFR trainer{prm, board, pot, position, threads};
        BestResponse br{prm};

        float final_exploit = 0.0f;
        trainer.train(root.get(), iterations, -1.0,
            [&](int i, int total, float exploit) {
                if (i == total && exploit >= 0) {
                    final_exploit = exploit;
                }
            });

        auto t_train = std::chrono::high_resolution_clock::now();

        // Calculate final exploitability
        final_exploit = br.get_exploitability(root.get(), iterations, board, pot, position);

        // Helper function to convert Action to string
        auto action_to_string = [](const Action& action) -> std::string {
            std::string result;
            switch (action.type) {
                case Action::FOLD: result = "Fold"; break;
                case Action::CHECK: result = "Check"; break;
                case Action::CALL: result = "Call"; break;
                case Action::BET: result = "Bet"; break;
                case Action::RAISE: result = "Raise"; break;
            }
            if (action.amount > 0) {
                result += " " + std::to_string(action.amount);
            }
            return result;
        };

        // Extract strategies
        json strategies = json::array();

        // Get strategy from root node (first decision)
        if (root->get_node_type() == NodeType::ACTION_NODE) {
            ActionNode* action_node = static_cast<ActionNode*>(root.get());
            auto avg_strategy = action_node->get_average_strat();

            const auto& actions = action_node->get_actions();
            int num_hands = action_node->get_num_hands();
            int num_actions = actions.size();

            // Group by hand
            for (int h = 0; h < num_hands && h < 20; ++h) { // Limit output
                json hand_strat;
                hand_strat["hand_index"] = h;

                json action_probs = json::array();
                for (int a = 0; a < num_actions; ++a) {
                    json action_data;
                    action_data["action"] = action_to_string(actions[a]);
                    action_data["probability"] = avg_strategy[h + a * num_hands];
                    action_probs.push_back(action_data);
                }
                hand_strat["actions"] = action_probs;
                strategies.push_back(hand_strat);
            }
        }

        // Output JSON
        json output;
        output["status"] = "success";
        output["exploitability"] = final_exploit;
        output["tree_build_time_ms"] = std::chrono::duration<double, std::milli>(t_tree - t_start).count();
        output["training_time_ms"] = std::chrono::duration<double, std::milli>(t_train - t_tree).count();
        output["total_time_ms"] = std::chrono::duration<double, std::milli>(t_train - t_start).count();
        output["tree_stats"]["action_nodes"] = stats.total_action_nodes;
        output["tree_stats"]["chance_nodes"] = stats.chance_nodes;
        output["tree_stats"]["terminal_nodes"] = stats.terminal_nodes;
        output["tree_stats"]["memory_mb"] = stats.estimateMemoryBytes() / 1024 / 1024;
        output["hero_combos"] = hero_range.num_hands;
        output["villain_combos"] = villain_range.num_hands;
        output["strategies"] = strategies;

        std::cout << output.dump(2) << std::endl;

        return 0;
    }
    catch (const std::exception& e) {
        json error;
        error["status"] = "error";
        error["message"] = e.what();
        std::cout << error.dump(2) << std::endl;
        return 1;
    }
}
