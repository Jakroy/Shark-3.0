// --------------------------------
// Pruning Helper - Reach Probability Pruning
// Skips subtrees with very low reach probabilities
// --------------------------------
#pragma once
#include <vector>
#include <algorithm>
#include <cmath>
#include <iostream>

class PruningHelper {
public:
    // Default threshold: 0.1% = 0.001
    static inline float reach_probability_threshold = 0.001f;

    // Enable/disable pruning
    static inline bool enable_pruning = true;

    // Statistics for monitoring pruning effectiveness
    static inline size_t nodes_visited = 0;
    static inline size_t nodes_pruned = 0;

    /**
     * Check if a subtree should be pruned based on reach probabilities
     *
     * @param reach_probs Vector of reach probabilities for all hands
     * @return true if subtree should be pruned (skipped), false otherwise
     */
    static bool should_prune(const std::vector<float>& reach_probs) {
        if (!enable_pruning) {
            return false;
        }

        // If all reach probabilities are below threshold, prune
        // We check max to be more aggressive (if max is below, all are below)
        float max_reach = get_max_reach_probability(reach_probs);

        bool prune = max_reach < reach_probability_threshold;

        if (prune) {
            nodes_pruned++;
        }
        nodes_visited++;

        return prune;
    }

    /**
     * Check if a subtree should be pruned using both hero and villain reach probs
     * For action nodes, we check the current player's reach probability
     *
     * @param hero_reach_probs Hero's reach probabilities
     * @param villain_reach_probs Villain's reach probabilities
     * @param check_hero If true, check hero's reach; otherwise check villain's
     * @return true if subtree should be pruned
     */
    static bool should_prune_action_node(const std::vector<float>& hero_reach_probs,
                                          const std::vector<float>& villain_reach_probs,
                                          bool check_hero) {
        if (!enable_pruning) {
            return false;
        }

        // Check the current player's reach probability
        const auto& probs_to_check = check_hero ? hero_reach_probs : villain_reach_probs;

        float max_reach = get_max_reach_probability(probs_to_check);

        bool prune = max_reach < reach_probability_threshold;

        if (prune) {
            nodes_pruned++;
        }
        nodes_visited++;

        return prune;
    }

    /**
     * Get the maximum reach probability from a vector
     * This is the most aggressive pruning criterion
     */
    static float get_max_reach_probability(const std::vector<float>& reach_probs) {
        if (reach_probs.empty()) {
            return 0.0f;
        }

        // Vectorizable: compilers can use SIMD max instructions
        float max_prob = reach_probs[0];
        for (size_t i = 1; i < reach_probs.size(); ++i) {
            if (reach_probs[i] > max_prob) {
                max_prob = reach_probs[i];
            }
        }

        return max_prob;
    }

    /**
     * Alternative: Get the sum of reach probabilities
     * More conservative - only prune if total probability mass is tiny
     */
    static float get_total_reach_probability(const std::vector<float>& reach_probs) {
        float sum = 0.0f;
        for (float prob : reach_probs) {
            sum += prob;
        }
        return sum;
    }

    /**
     * Alternative: Check if average reach probability is below threshold
     * Middle ground between max and total
     */
    static bool should_prune_by_average(const std::vector<float>& reach_probs) {
        if (!enable_pruning || reach_probs.empty()) {
            return false;
        }

        float avg = get_total_reach_probability(reach_probs) / reach_probs.size();

        bool prune = avg < reach_probability_threshold;

        if (prune) {
            nodes_pruned++;
        }
        nodes_visited++;

        return prune;
    }

    /**
     * Reset pruning statistics
     */
    static void reset_statistics() {
        nodes_visited = 0;
        nodes_pruned = 0;
    }

    /**
     * Get pruning efficiency as a percentage
     */
    static float get_pruning_percentage() {
        if (nodes_visited == 0) {
            return 0.0f;
        }
        return (100.0f * nodes_pruned) / nodes_visited;
    }

    /**
     * Print pruning statistics
     */
    static void print_statistics() {
        if (!enable_pruning) {
            return;
        }

        float percentage = get_pruning_percentage();
        std::cout << "Pruning Statistics:" << std::endl;
        std::cout << "  Nodes visited: " << nodes_visited << std::endl;
        std::cout << "  Nodes pruned: " << nodes_pruned << std::endl;
        std::cout << "  Pruning rate: " << percentage << "%" << std::endl;
    }
};
