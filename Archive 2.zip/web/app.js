// Shark GTO Solver - Web Frontend
// Application logic for the web interface

const RANKS = ['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2'];
const SUITS = {
    'h': '♥',
    'd': '♦',
    'c': '♣',
    's': '♠'
};

let selectedBoard = [];
let currentRangeType = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeCardSelector();
    initializeRangeGrids();
    checkServerHealth();
});

// Check if server is running
async function checkServerHealth() {
    try {
        const response = await fetch('http://localhost:8080/api/health');
        const data = await response.json();
        if (!data.solver_available) {
            alert('Warning: Solver executable not found. Please build the project first.');
        }
    } catch (error) {
        console.error('Server health check failed:', error);
    }
}

// Initialize card selector for board
function initializeCardSelector() {
    const selector = document.getElementById('card-selector');
    selector.innerHTML = '';

    RANKS.forEach(rank => {
        Object.keys(SUITS).forEach(suit => {
            const btn = document.createElement('div');
            btn.className = 'card-btn';
            btn.dataset.card = rank + suit;

            btn.innerHTML = `
                <span class="rank">${rank}</span>
                <span class="suit ${suit === 'h' || suit === 'd' ? 'red' : 'black'}">${SUITS[suit]}</span>
            `;

            btn.onclick = () => selectCard(rank + suit, btn);
            selector.appendChild(btn);
        });
    });
}

// Select a card for the board
function selectCard(card, btn) {
    if (btn.classList.contains('disabled')) return;

    if (selectedBoard.length < 5) {
        selectedBoard.push(card);
        btn.classList.add('selected');
        btn.classList.add('disabled');
        updateBoardDisplay();
    }
}

// Update board display
function updateBoardDisplay() {
    const display = document.getElementById('board-display');
    const slots = display.querySelectorAll('.board-slot');

    slots.forEach((slot, index) => {
        if (index < selectedBoard.length) {
            const card = selectedBoard[index];
            const suit = card[card.length - 1];
            const rank = card.substring(0, card.length - 1);

            slot.textContent = rank + SUITS[suit];
            slot.className = 'board-slot card ' + suit;
            if (suit === 'h' || suit === 'd') {
                slot.classList.add('hearts', 'diamonds');
            } else {
                slot.classList.add('clubs', 'spades');
            }
        } else {
            slot.textContent = '?';
            slot.className = 'board-slot empty';
        }
    });
}

// Clear board
function clearBoard() {
    selectedBoard = [];
    updateBoardDisplay();

    // Re-enable all cards
    document.querySelectorAll('.card-btn').forEach(btn => {
        btn.classList.remove('selected', 'disabled');
    });
}

// Initialize range grids
function initializeRangeGrids() {
    initializeRangeGrid('hero');
    initializeRangeGrid('villain');
}

function initializeRangeGrid(type) {
    const grid = document.getElementById(`${type}-range-grid`);
    grid.innerHTML = '';

    // Create 13x13 grid
    for (let i = 0; i < RANKS.length; i++) {
        for (let j = 0; j < RANKS.length; j++) {
            const cell = document.createElement('div');
            cell.className = 'range-cell';

            let hand;
            if (i === j) {
                // Pocket pair
                hand = RANKS[i] + RANKS[i];
                cell.classList.add('pair');
            } else if (i < j) {
                // Suited
                hand = RANKS[i] + RANKS[j] + 's';
                cell.classList.add('suited');
            } else {
                // Offsuit
                hand = RANKS[j] + RANKS[i] + 'o';
                cell.classList.add('offsuit');
            }

            cell.textContent = hand;
            cell.dataset.hand = hand;
            cell.onclick = () => toggleRangeCell(cell, type);

            grid.appendChild(cell);
        }
    }
}

function toggleRangeCell(cell, type) {
    cell.classList.toggle('selected');
    updateRangeInput(type);
}

function updateRangeInput(type) {
    const grid = document.getElementById(`${type}-range-grid`);
    const selected = Array.from(grid.querySelectorAll('.range-cell.selected'))
        .map(cell => cell.dataset.hand);

    document.getElementById(`${type}-range-input`).value = selected.join(',');
}

function showRangeGrid(type) {
    const grid = document.getElementById(`${type}-range-grid`);
    grid.classList.toggle('hidden');

    if (!grid.classList.contains('hidden')) {
        // Parse current input and select cells
        const input = document.getElementById(`${type}-range-input`).value;
        parseAndSelectRange(type, input);
    }
}

function parseAndSelectRange(type, rangeString) {
    const grid = document.getElementById(`${type}-range-grid`);
    const cells = grid.querySelectorAll('.range-cell');

    // Clear all selections
    cells.forEach(cell => cell.classList.remove('selected'));

    // Simple parsing - just match exact hands
    const hands = rangeString.split(',').map(h => h.trim());
    cells.forEach(cell => {
        if (hands.includes(cell.dataset.hand)) {
            cell.classList.add('selected');
        }
    });
}

// Main solve function
async function solve() {
    const solveBtn = document.getElementById('solve-btn');
    const results = document.getElementById('results');

    // Validate inputs
    if (selectedBoard.length < 3) {
        alert('Please select at least 3 board cards (flop)');
        return;
    }

    const heroRange = document.getElementById('hero-range-input').value.trim();
    const villainRange = document.getElementById('villain-range-input').value.trim();

    if (!heroRange || !villainRange) {
        alert('Please enter ranges for both players');
        return;
    }

    // Gather inputs
    const data = {
        hero_range: heroRange,
        villain_range: villainRange,
        board: selectedBoard,
        stack: parseInt(document.getElementById('stack').value),
        pot: parseInt(document.getElementById('pot').value),
        min_bet: parseInt(document.getElementById('min-bet').value),
        position: parseInt(document.getElementById('position').value),
        iterations: parseInt(document.getElementById('iterations').value),
        threads: parseInt(document.getElementById('threads').value)
    };

    // Show loading state
    solveBtn.disabled = true;
    solveBtn.textContent = 'Solving...';
    results.innerHTML = '<div class="loading"><div class="spinner"></div><p>Solving scenario...</p></div>';

    try {
        const response = await fetch('http://localhost:8080/api/solve', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.status === 'error') {
            throw new Error(result.message);
        }

        displayResults(result);
    } catch (error) {
        results.innerHTML = `
            <div class="error" style="color: #f44336; padding: 20px; text-align: center;">
                <h3>Error</h3>
                <p>${error.message}</p>
                <p style="margin-top: 10px; color: #666; font-size: 0.9em;">
                    Make sure the server is running and the solver is built.
                </p>
            </div>
        `;
        console.error('Solve error:', error);
    } finally {
        solveBtn.disabled = false;
        solveBtn.textContent = 'Solve';
    }
}

// Display results
function displayResults(result) {
    const results = document.getElementById('results');

    let html = `
        <div class="results-header">
            <h3>✓ Solution Complete</h3>
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-label">Exploitability:</span>
                    <span class="stat-value">${result.exploitability.toFixed(3)}%</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Total Time:</span>
                    <span class="stat-value">${(result.total_time_ms / 1000).toFixed(2)}s</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Tree Build Time:</span>
                    <span class="stat-value">${(result.tree_build_time_ms / 1000).toFixed(2)}s</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Training Time:</span>
                    <span class="stat-value">${(result.training_time_ms / 1000).toFixed(2)}s</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Action Nodes:</span>
                    <span class="stat-value">${result.tree_stats.action_nodes.toLocaleString()}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Memory Used:</span>
                    <span class="stat-value">${result.tree_stats.memory_mb} MB</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Hero Combos:</span>
                    <span class="stat-value">${result.hero_combos}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Villain Combos:</span>
                    <span class="stat-value">${result.villain_combos}</span>
                </div>
            </div>
        </div>

        <h3>Strategy (First ${result.strategies.length} Hands)</h3>
        <table class="strategy-table">
            <thead>
                <tr>
                    <th>Hand</th>
                    <th>Actions</th>
                    <th>Distribution</th>
                </tr>
            </thead>
            <tbody>
    `;

    result.strategies.forEach((strat, idx) => {
        html += `
            <tr>
                <td><strong>#${strat.hand_index}</strong></td>
                <td>`;

        strat.actions.forEach(action => {
            const pct = (action.probability * 100).toFixed(1);
            html += `<div>${action.action}: ${pct}%</div>`;
        });

        html += `</td><td>`;

        // Visual action bar
        html += `<div class="action-bar">`;
        strat.actions.forEach(action => {
            const width = (action.probability * 100);
            if (width > 1) {
                const actionType = action.action.toLowerCase().includes('fold') ? 'fold' :
                                 action.action.toLowerCase().includes('check') ? 'check' :
                                 action.action.toLowerCase().includes('call') ? 'call' :
                                 action.action.toLowerCase().includes('bet') ? 'bet' : 'raise';
                html += `<div class="action-segment action-${actionType}" style="width: ${width}%">${width > 10 ? width.toFixed(0) + '%' : ''}</div>`;
            }
        });
        html += `</div>`;

        html += `</td></tr>`;
    });

    html += `
            </tbody>
        </table>
    `;

    results.innerHTML = html;
}

// Fix typo in HTML - rename function
function solvescenario() {
    solve();
}
