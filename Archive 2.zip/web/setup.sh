#!/bin/bash
# Shark GTO Solver - Web Interface Setup Script

echo "======================================"
echo "Shark GTO Solver - Web Interface Setup"
echo "======================================"
echo ""

# Check if we're in the right directory
if [ ! -f "server.py" ]; then
    echo "Error: Please run this script from the web/ directory"
    exit 1
fi

echo "Step 1: Checking dependencies..."
echo ""

# Check for Python3
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
echo "✓ Python 3 found: $(python3 --version)"

# Check for pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip first."
    exit 1
fi
echo "✓ pip3 found"

# Check for CMake
if ! command -v cmake &> /dev/null; then
    echo "❌ CMake is not installed. Please install CMake first."
    exit 1
fi
echo "✓ CMake found: $(cmake --version | head -n1)"

echo ""
echo "Step 2: Installing Python dependencies..."
echo ""

pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install Python dependencies"
    exit 1
fi
echo "✓ Python dependencies installed"

echo ""
echo "Step 3: Building JSON solver..."
echo ""

cd ..
if [ ! -d "build" ]; then
    mkdir build
fi

cd build
cmake ..
make json_solver

if [ $? -ne 0 ]; then
    echo "❌ Failed to build JSON solver"
    exit 1
fi
echo "✓ JSON solver built successfully"

cd ../web

echo ""
echo "======================================"
echo "✓ Setup Complete!"
echo "======================================"
echo ""
echo "To start the web interface, run:"
echo "  python3 server.py"
echo ""
echo "Then open your browser to:"
echo "  http://localhost:5000"
echo ""
echo "======================================"
