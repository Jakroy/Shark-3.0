# Shark GTO Solver - Web Interface

A user-friendly web-based interface for the Shark GTO poker solver.

## Features

- 🎯 **Visual Range Selector**: Click to build ranges on an interactive grid
- 🃏 **Board Card Selector**: Visual card picker for flop, turn, and river
- 📊 **Strategy Visualization**: View optimal strategies with action frequencies and EV charts
- ⚡ **Real-time Solving**: Fast multi-threaded solver with progress updates
- 🎨 **Modern UI**: Clean, responsive design that works on desktop and mobile

## Quick Start

### 1. Build the JSON Solver

First, make sure you have the required JSON header (already downloaded):

```bash
cd /Users/ajyork/Desktop/shark-2.0
mkdir build && cd build
cmake ..
make json_solver
```

This will create the `json_solver` executable in the `build/` directory.

### 2. Install Python Dependencies

```bash
cd /Users/ajyork/Desktop/shark-2.0/web
pip3 install -r requirements.txt
```

Or if you prefer using a virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Start the Web Server

```bash
python3 server.py
```

The server will start on http://localhost:5000

### 4. Open in Browser

Navigate to http://localhost:5000 in your web browser.

## Usage

1. **Select Board Cards**: Click on cards to select flop (3 cards minimum), turn, and river
2. **Set Ranges**: Enter range strings or use the visual grid selector
   - Example: `AA,KK,QQ,AKs,AKo`
   - Use `+` for ranges: `55+` (all pairs 55 and better)
   - Use `s` for suited, `o` for offsuit
3. **Configure Settings**:
   - Stack size
   - Pot size
   - Position (IP/OOP)
   - Number of iterations
   - Thread count
4. **Click Solve**: Wait for the solver to complete
5. **View Results**: See exploitability, strategies, and action frequencies

## Range Notation

The solver supports standard poker range notation:

- **Specific hands**: `AA`, `KK`, `AKs`, `AKo`
- **Ranges**: `55+` (pairs 55 and better), `A2s+` (all suited aces)
- **Multiple hands**: `AA,KK,QQ` (comma-separated)
- **Complete ranges**: `55+,A2s+,K7s+,A9o+`

## API Endpoints

### POST /api/solve

Solve a poker scenario.

**Request Body:**
```json
{
  "hero_range": "AA,KK,QQ,AKs",
  "villain_range": "33+,A2s+,K2s+",
  "board": ["Ks", "Qh", "7d"],
  "stack": 100,
  "pot": 10,
  "min_bet": 2,
  "position": 2,
  "iterations": 100,
  "threads": 4
}
```

**Response:**
```json
{
  "status": "success",
  "exploitability": 0.123,
  "total_time_ms": 5234,
  "tree_stats": {
    "action_nodes": 8234,
    "memory_mb": 256
  },
  "strategies": [...]
}
```

### GET /api/health

Check server health and solver availability.

**Response:**
```json
{
  "status": "ok",
  "solver_available": true,
  "solver_path": "/path/to/json_solver"
}
```

## Configuration

### Solver Settings

Edit `server.py` to change the solver path if needed:

```python
SOLVER_PATH = os.path.join(os.path.dirname(__file__), '..', 'build', 'json_solver')
```

### Server Port

Change the port in `server.py`:

```python
app.run(debug=True, host='0.0.0.0', port=5000)  # Change 5000 to your port
```

## Troubleshooting

### Solver not found

Make sure you've built the `json_solver` target:

```bash
cd build
make json_solver
```

### Server won't start

Check that Flask is installed:

```bash
pip3 install Flask flask-cors
```

### Slow solving

- Reduce iterations (try 50-100 for testing)
- Increase thread count to match your CPU cores
- Use tighter ranges to reduce combinations

### CORS errors

Make sure `flask-cors` is installed. The server is configured to accept requests from any origin.

## Architecture

```
web/
├── index.html       # Frontend UI
├── style.css        # Styling
├── app.js           # JavaScript logic
├── server.py        # Flask backend
├── requirements.txt # Python dependencies
└── README.md        # This file

src/cli/
└── json_solver.cpp  # JSON CLI solver

build/
└── json_solver      # Compiled solver executable
```

## Performance

Typical solve times on a modern machine (8 cores):

- **Flop (3 cards)**: 5-30 seconds for 100 iterations
- **Turn (4 cards)**: 30-120 seconds for 100 iterations
- **River (5 cards)**: 2-10 minutes for 100 iterations

Performance depends on:
- Range sizes
- Number of betting actions
- Stack-to-pot ratio
- Thread count

## Development

To modify the frontend:

1. Edit `index.html`, `style.css`, or `app.js`
2. Refresh your browser (no rebuild needed)

To modify the solver:

1. Edit `src/cli/json_solver.cpp`
2. Rebuild: `cd build && make json_solver`
3. Restart the server

## License

Same as the main Shark project.

## Credits

- **Solver Engine**: Shark 2.0 (DCFR implementation)
- **Hand Evaluator**: PokerHandEvaluator by HenryRLee
- **Web Framework**: Flask
- **Frontend**: Vanilla JavaScript (no framework dependencies)
