#!/usr/bin/env python3
"""
Shark GTO Solver - Web Server
Simple Flask server that interfaces with the JSON solver CLI
"""
import json
import subprocess
import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='.')
CORS(app)

# Path to the JSON solver executable
SOLVER_PATH = os.path.join(os.path.dirname(__file__), '..', 'build', 'json_solver')

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Serve static files (CSS, JS, images)"""
    return send_from_directory('.', path)

@app.route('/api/solve', methods=['POST'])
def solve():
    """
    Solve a poker scenario
    Expected JSON format:
    {
        "hero_range": "AA,KK,QQ",
        "villain_range": "33+,A2s+",
        "board": ["Ks", "Qh", "7d"],
        "stack": 100,
        "pot": 10,
        "position": 2,
        "iterations": 100,
        "threads": 4
    }
    """
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = ['hero_range', 'villain_range', 'board']
        for field in required_fields:
            if field not in data:
                return jsonify({'status': 'error', 'message': f'Missing required field: {field}'}), 400

        # Set defaults
        if 'stack' not in data:
            data['stack'] = 100
        if 'pot' not in data:
            data['pot'] = 10
        if 'min_bet' not in data:
            data['min_bet'] = 2
        if 'position' not in data:
            data['position'] = 2
        if 'iterations' not in data:
            data['iterations'] = 100
        if 'threads' not in data:
            data['threads'] = 4

        # Call the solver
        process = subprocess.Popen(
            [SOLVER_PATH],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        stdout, stderr = process.communicate(input=json.dumps(data))

        if process.returncode != 0:
            return jsonify({
                'status': 'error',
                'message': f'Solver failed: {stderr}'
            }), 500

        # Parse and return result
        result = json.loads(stdout)
        return jsonify(result)

    except FileNotFoundError:
        return jsonify({
            'status': 'error',
            'message': f'Solver executable not found at {SOLVER_PATH}. Please build the project first.'
        }), 500
    except json.JSONDecodeError as e:
        return jsonify({
            'status': 'error',
            'message': f'Invalid JSON: {str(e)}'
        }), 400
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    solver_exists = os.path.exists(SOLVER_PATH)
    return jsonify({
        'status': 'ok',
        'solver_available': solver_exists,
        'solver_path': SOLVER_PATH
    })

if __name__ == '__main__':
    print("=" * 60)
    print("Shark GTO Solver - Web Interface")
    print("=" * 60)
    print(f"Solver path: {SOLVER_PATH}")
    print(f"Solver exists: {os.path.exists(SOLVER_PATH)}")
    print("\nStarting server on http://localhost:8080")
    print("Open your browser and navigate to http://localhost:8080")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=8080)
