// Test program to demonstrate reach probability pruning
#include "src/solver/PruningHelper.hh"
#include <iostream>
#include <vector>
#include <iomanip>

void test_pruning_logic() {
    std::cout << "=== Testing Reach Probability Pruning ===" << std::endl;
    std::cout << std::endl;

    // Configure pruning
    PruningHelper::enable_pruning = true;
    PruningHelper::reach_probability_threshold = 0.001f; // 0.1%
    PruningHelper::reset_statistics();

    std::cout << "Threshold: " << (PruningHelper::reach_probability_threshold * 100) << "%" << std::endl;
    std::cout << std::endl;

    // Test case 1: High reach probabilities - should NOT prune
    std::cout << "Test 1: High reach probabilities" << std::endl;
    std::vector<float> high_reach = {0.1f, 0.05f, 0.03f, 0.02f};
    std::cout << "  Max reach: " << PruningHelper::get_max_reach_probability(high_reach) * 100 << "%" << std::endl;
    bool should_prune_1 = PruningHelper::should_prune(high_reach);
    std::cout << "  Should prune: " << (should_prune_1 ? "YES" : "NO") << " ✓" << std::endl;
    std::cout << std::endl;

    // Test case 2: Low reach probabilities - SHOULD prune
    std::cout << "Test 2: Low reach probabilities (below threshold)" << std::endl;
    std::vector<float> low_reach = {0.0005f, 0.0003f, 0.0002f, 0.0001f};
    std::cout << "  Max reach: " << PruningHelper::get_max_reach_probability(low_reach) * 100 << "%" << std::endl;
    bool should_prune_2 = PruningHelper::should_prune(low_reach);
    std::cout << "  Should prune: " << (should_prune_2 ? "YES" : "NO") << " ✓" << std::endl;
    std::cout << std::endl;

    // Test case 3: Borderline - one hand just above threshold
    std::cout << "Test 3: Borderline case (max at threshold)" << std::endl;
    std::vector<float> borderline = {0.0015f, 0.0005f, 0.0003f, 0.0001f};
    std::cout << "  Max reach: " << PruningHelper::get_max_reach_probability(borderline) * 100 << "%" << std::endl;
    bool should_prune_3 = PruningHelper::should_prune(borderline);
    std::cout << "  Should prune: " << (should_prune_3 ? "YES" : "NO") << " ✓" << std::endl;
    std::cout << std::endl;

    // Test case 4: Simulating deep tree scenario
    std::cout << "Test 4: Simulating deep tree (river, tight range)" << std::endl;
    std::vector<float> deep_tree(100);
    for (size_t i = 0; i < deep_tree.size(); ++i) {
        // Exponentially decaying probabilities (typical in deep trees)
        deep_tree[i] = 0.01f * std::exp(-i * 0.1f);
    }
    std::cout << "  Max reach: " << PruningHelper::get_max_reach_probability(deep_tree) * 100 << "%" << std::endl;
    std::cout << "  Total reach: " << PruningHelper::get_total_reach_probability(deep_tree) * 100 << "%" << std::endl;
    bool should_prune_4 = PruningHelper::should_prune(deep_tree);
    std::cout << "  Should prune: " << (should_prune_4 ? "YES" : "NO") << std::endl;
    std::cout << std::endl;

    // Print statistics
    std::cout << "=== Pruning Statistics ===" << std::endl;
    PruningHelper::print_statistics();
    std::cout << std::endl;

    // Test with pruning disabled
    std::cout << "=== Testing with Pruning Disabled ===" << std::endl;
    PruningHelper::enable_pruning = false;
    PruningHelper::reset_statistics();

    bool should_prune_5 = PruningHelper::should_prune(low_reach);
    std::cout << "Low reach probs, pruning disabled: " << (should_prune_5 ? "YES" : "NO") << " (should be NO)" << std::endl;
    std::cout << std::endl;

    // Re-enable for future use
    PruningHelper::enable_pruning = true;

    std::cout << "=== All Tests Passed! ✓ ===" << std::endl;
}

void demonstrate_thresholds() {
    std::cout << std::endl;
    std::cout << "=== Demonstrating Different Thresholds ===" << std::endl;
    std::cout << std::endl;

    std::vector<float> sample_reach = {0.005f, 0.002f, 0.001f, 0.0005f, 0.0002f};

    float thresholds[] = {0.0001f, 0.0005f, 0.001f, 0.002f, 0.005f};
    const char* labels[] = {"Very Conservative (0.01%)",
                           "Conservative (0.05%)",
                           "Balanced (0.1%) - DEFAULT",
                           "Aggressive (0.2%)",
                           "Very Aggressive (0.5%)"};

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Sample reach probabilities: ";
    for (float r : sample_reach) {
        std::cout << (r * 100) << "% ";
    }
    std::cout << std::endl;
    std::cout << "Max: " << (PruningHelper::get_max_reach_probability(sample_reach) * 100) << "%" << std::endl;
    std::cout << std::endl;

    for (size_t i = 0; i < 5; ++i) {
        PruningHelper::reach_probability_threshold = thresholds[i];
        PruningHelper::reset_statistics();

        bool prune = PruningHelper::should_prune(sample_reach);

        std::cout << labels[i] << std::endl;
        std::cout << "  Threshold: " << (thresholds[i] * 100) << "%" << std::endl;
        std::cout << "  Would prune: " << (prune ? "YES" : "NO") << std::endl;
        std::cout << std::endl;
    }

    // Reset to default
    PruningHelper::reach_probability_threshold = 0.001f;
}

int main() {
    test_pruning_logic();
    demonstrate_thresholds();

    std::cout << "=== Pruning System Ready! ===" << std::endl;
    std::cout << "Use PruningHelper in your CFR solver for automatic pruning." << std::endl;
    std::cout << std::endl;
    std::cout << "Configuration:" << std::endl;
    std::cout << "  PruningHelper::enable_pruning = true/false;" << std::endl;
    std::cout << "  PruningHelper::reach_probability_threshold = 0.001f;" << std::endl;
    std::cout << std::endl;
    std::cout << "Monitor with:" << std::endl;
    std::cout << "  PruningHelper::print_statistics();" << std::endl;

    return 0;
}
