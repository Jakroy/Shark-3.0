#!/bin/bash
set -e

echo "============================================"
echo "Shark 3.0 - Ubuntu Build Script"
echo "============================================"

# Check if running on Ubuntu/Debian
if ! command -v apt &> /dev/null; then
    echo "Error: This script is designed for Ubuntu/Debian systems"
    exit 1
fi

# Check for required packages
echo "Checking dependencies..."
MISSING_DEPS=()

check_package() {
    if ! dpkg -l | grep -q "^ii  $1 "; then
        MISSING_DEPS+=("$1")
    fi
}

check_package "build-essential"
check_package "cmake"
check_package "libtbb-dev"
check_package "libpng-dev"
check_package "zlib1g-dev"
check_package "libx11-dev"
check_package "libxft-dev"
check_package "libfontconfig1-dev"

if [ ${#MISSING_DEPS[@]} -ne 0 ]; then
    echo ""
    echo "Missing dependencies: ${MISSING_DEPS[*]}"
    echo ""
    echo "Install with:"
    echo "  sudo apt update"
    echo "  sudo apt install -y ${MISSING_DEPS[*]}"
    echo ""
    read -p "Would you like to install them now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo apt update
        sudo apt install -y ${MISSING_DEPS[@]}
    else
        echo "Please install missing dependencies and run this script again."
        exit 1
    fi
fi

# Check if libjpeg is installed (handle both libjpeg-turbo and libjpeg)
if ! dpkg -l | grep -q "^ii  libjpeg.*-dev "; then
    echo "Installing libjpeg development libraries..."
    sudo apt install -y libjpeg-turbo8-dev || sudo apt install -y libjpeg-dev
fi

# Check for additional X11 libraries
X11_DEPS=("libxext-dev" "libxinerama-dev" "libxcursor-dev" "libxfixes-dev" "libxrender-dev")
for dep in "${X11_DEPS[@]}"; do
    if ! dpkg -l | grep -q "^ii  $dep "; then
        echo "Installing $dep..."
        sudo apt install -y "$dep"
    fi
done

# Check for DejaVu fonts
if ! dpkg -l | grep -q "^ii  fonts-dejavu "; then
    echo "Installing DejaVu fonts for GUI..."
    sudo apt install -y fonts-dejavu
fi

# Check for FLTK installation
echo ""
echo "Checking for FLTK 1.4.4..."
if ! pkg-config --exists fltk && [ ! -f /usr/local/lib/libfltk.a ]; then
    echo "FLTK 1.4.4 not found. Building from source..."
    echo "This will take 5-10 minutes..."
    echo ""

    # Create temp directory
    TEMP_DIR=$(mktemp -d)
    cd "$TEMP_DIR"

    # Download FLTK 1.4.4
    echo "Downloading FLTK 1.4.4..."
    wget -q --show-progress https://www.fltk.org/pub/fltk/1.4.4/fltk-1.4.4-source.tar.gz
    tar xzf fltk-1.4.4-source.tar.gz
    cd fltk-1.4.4

    # Build FLTK
    echo "Building FLTK 1.4.4..."
    cmake -S . -B build \
        -DCMAKE_BUILD_TYPE=Release \
        -DFLTK_BUILD_SHARED_LIBS=OFF \
        -DFLTK_BUILD_TEST=OFF \
        -DFLTK_BUILD_EXAMPLES=OFF \
        -DCMAKE_INSTALL_PREFIX=/usr/local \
        > /dev/null

    cmake --build build --parallel $(nproc) > /dev/null

    # Install FLTK (requires sudo)
    echo "Installing FLTK 1.4.4 to /usr/local..."
    sudo cmake --install build > /dev/null

    # Cleanup
    cd ~
    rm -rf "$TEMP_DIR"

    echo "FLTK 1.4.4 installed successfully!"
else
    echo "FLTK 1.4.4 found!"
fi

# Initialize submodules if needed
if [ ! -f include/PokerHandEvaluator/cpp/CMakeLists.txt ]; then
    echo ""
    echo "Initializing PokerHandEvaluator submodule..."
    git submodule update --init --recursive
fi

# Build Shark
echo ""
echo "============================================"
echo "Building Shark 3.0..."
echo "============================================"

# Return to project directory
cd "$(dirname "$0")"

# Create build directory
mkdir -p build
cd build

# Configure CMake
echo "Configuring with CMake..."
cmake -S .. -B . \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_STANDARD=20 \
    -DCMAKE_CXX_EXTENSIONS=OFF \
    -DCMAKE_CXX_FLAGS="-O3 -ffast-math"

# Build with all available cores
echo "Compiling (using $(nproc) cores)..."
cmake --build . --parallel $(nproc)

echo ""
echo "============================================"
echo "Build completed successfully!"
echo "============================================"
echo ""
echo "Executables built:"
echo "  - GUI:       ./build/shark"
echo "  - CLI:       ./build/shark_cli"
echo "  - JSON API:  ./build/json_solver"
echo ""
echo "To run the GUI:"
echo "  cd build && ./shark"
echo ""
echo "To run the CLI solver:"
echo "  cd build && ./shark_cli"
echo ""
echo "To start the JSON API server:"
echo "  cd build && ./json_solver"
echo ""
echo "============================================"
