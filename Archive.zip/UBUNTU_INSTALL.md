# Ubuntu Installation Guide for Shark 3.0

This guide covers building Shark 3.0 poker solver on Ubuntu Linux.

## Tested Platforms

- ✅ Ubuntu 24.04 LTS (Noble Numbat)
- ✅ Ubuntu 22.04 LTS (Jammy Jellyfish)
- ✅ Ubuntu 20.04 LTS (Focal Fossa)

---

## Quick Start

### Automated Build (Recommended)

The easiest way to build Shark 3.0 on Ubuntu:

```bash
./build_ubuntu.sh
```

This script will:
- Check for required dependencies
- Offer to install missing packages
- Build FLTK 1.4.4 from source if needed
- Build all three Shark executables

After building, run the GUI:
```bash
cd build
./shark
```

---

## Manual Build

If you prefer to build manually or the automated script doesn't work:

### 1. Install Dependencies

```bash
sudo apt update
sudo apt install -y \
  build-essential cmake git pkg-config \
  libtbb-dev \
  libpng-dev libjpeg-turbo8-dev zlib1g-dev \
  libx11-dev libxext-dev libxft-dev libfontconfig1-dev \
  libxinerama-dev libxcursor-dev libxfixes-dev libxrender-dev \
  fonts-dejavu
```

**Note:** On older Ubuntu versions, use `libjpeg-dev` if `libjpeg-turbo8-dev` is not available.

### 2. Build FLTK 1.4.4

Ubuntu repositories contain FLTK 1.3.x, but Shark requires 1.4.4. You must build it from source:

```bash
cd /tmp
wget https://www.fltk.org/pub/fltk/1.4.4/fltk-1.4.4-source.tar.gz
tar xzf fltk-1.4.4-source.tar.gz
cd fltk-1.4.4

cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DFLTK_BUILD_SHARED_LIBS=OFF \
  -DFLTK_BUILD_TEST=OFF \
  -DFLTK_BUILD_EXAMPLES=OFF \
  -DCMAKE_INSTALL_PREFIX=/usr/local

cmake --build build --parallel $(nproc)
sudo cmake --install build
```

This installs FLTK to `/usr/local` (requires sudo).

### 3. Clone and Build Shark

```bash
# Clone repository with submodules
git clone --recursive https://github.com/your-repo/shark-3.0.git
cd shark-3.0

# If you already cloned without --recursive:
git submodule update --init --recursive

# Build Shark
mkdir build && cd build
cmake -S .. -B . -DCMAKE_BUILD_TYPE=Release
cmake --build . --parallel $(nproc)
```

### 4. Run Shark

```bash
# GUI application
./shark

# CLI solver
./shark_cli

# JSON API (for web interface)
./json_solver
```

---

## System Requirements

### Minimum

- **CPU:** Dual-core x86_64 processor
- **RAM:** 2 GB for turn/river solving
- **Disk:** 500 MB for installation
- **Display:** X11 (for GUI)

### Recommended

- **CPU:** Quad-core or better (for multi-threading)
- **RAM:** 8-16 GB for flop solving
- **Disk:** 1 GB free space

### Memory Requirements by Street

| Scenario | Typical RAM Usage |
|----------|------------------|
| River solving | < 1 GB |
| Turn solving | 2-4 GB |
| Flop solving | 8-16 GB |

---

## Troubleshooting

### Issue: "libfltk.a not found"

**Cause:** FLTK 1.4.4 not built from source

**Solution:**
1. Build FLTK 1.4.4 manually (see step 2 above)
2. Ensure it's installed to `/usr/local`
3. Verify installation: `ls /usr/local/lib/libfltk.a`

### Issue: "Cannot find -ltbb"

**Cause:** Intel TBB development libraries not installed

**Solution:**
```bash
sudo apt install libtbb-dev
```

### Issue: Font rendering looks ugly

**Cause:** DejaVu Sans fonts not installed

**Solution:**
```bash
sudo apt install fonts-dejavu
```

Shark uses DejaVu Sans on Linux for clean, readable text rendering.

### Issue: "Cannot open display" or X11 errors

**Cause:** Running on headless system or via SSH without X forwarding

**Solutions:**

1. **For headless servers:** Use CLI or JSON solver instead:
   ```bash
   ./shark_cli      # Command-line interface
   ./json_solver    # Web interface backend
   ```

2. **For SSH sessions:** Enable X forwarding:
   ```bash
   ssh -X user@hostname
   ./shark
   ```

3. **Using Xvfb (virtual display):**
   ```bash
   sudo apt install xvfb
   xvfb-run ./shark
   ```

### Issue: "PokerHandEvaluator not found"

**Cause:** Git submodule not initialized

**Solution:**
```bash
git submodule update --init --recursive
```

### Issue: CMake Error about TBB version

**Cause:** Incompatible TBB version

**Solution:**
```bash
# Check TBB version
dpkg -l | grep libtbb

# Update TBB
sudo apt update
sudo apt install --reinstall libtbb-dev
```

### Issue: Build fails with "cannot find -lX11"

**Cause:** X11 development libraries missing

**Solution:**
```bash
sudo apt install libx11-dev libxext-dev libxft-dev
```

### Issue: Linker error about PNG/JPEG/ZLIB

**Cause:** Image library development packages missing

**Solution:**
```bash
sudo apt install libpng-dev libjpeg-turbo8-dev zlib1g-dev
```

---

## Architecture Notes

### Static vs Dynamic Linking

The build system uses a hybrid linking approach:

| Library | Linking Type | Notes |
|---------|--------------|-------|
| **FLTK** | Static | Built from source to `/usr/local` |
| **TBB** | Dynamic | `libtbb.so` - static rarely available on Ubuntu |
| **PNG/JPEG/ZLIB** | Flexible | Tries static, falls back to dynamic |
| **X11 libraries** | Dynamic | System libraries |

This means the Shark binary requires `libtbb.so.12` at runtime but is otherwise fairly portable.

### Checking Dependencies

After building, verify runtime dependencies:

```bash
ldd build/shark
```

Expected dynamic libraries:
- `libtbb.so.12` - Intel Threading Building Blocks
- `libX11.so.6` - X11 display
- `libXft.so.2` - X11 font rendering
- `libfontconfig.so.1` - Font configuration
- System libraries (`libc.so.6`, `libm.so.6`, `libpthread.so.0`, etc.)

FLTK should be statically linked (no `libfltk.so` in output).

---

## Distribution

To create a redistributable binary package:

```bash
# Build with optimization
cmake -S .. -B . \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_FLAGS="-O3 -ffast-math" \
  -DCMAKE_EXE_LINKER_FLAGS="-static-libgcc -static-libstdc++"

cmake --build . --parallel $(nproc)

# Check dependencies
ldd shark

# Create tarball
tar czf shark_ubuntu_$(uname -m).tar.gz shark shark_cli json_solver
```

**Note:** Full static linking is not possible due to TBB and X11. Users will need:
- `libtbb-dev` (or `libtbb.so.12`)
- X11 libraries (for GUI)
- Fonts (DejaVu Sans recommended)

---

## Performance Comparison

Shark 3.0 on Ubuntu should perform similarly to macOS:

| Optimization | Status | Speedup |
|--------------|--------|---------|
| Multi-threading (TBB) | ✅ Enabled | 4-8x on quad-core |
| CFR+ algorithm | ✅ Enabled | 2-10x convergence |
| Reach probability pruning | ✅ Enabled | 1.2-2x |
| Hand isomorphism | ✅ Enabled | ~1.25x |
| SIMD optimizations | ✅ Auto-vectorized | Hardware dependent |

Benchmark your system:
```bash
# Test CFR+ convergence
./test_cfr_plus

# Test pruning effectiveness
./test_pruning
```

---

## Memory Detection

Shark detects system memory using `/proc/meminfo` on Linux:

```cpp
// Linux memory detection (gui/utils/MemoryUtil.hh)
std::ifstream meminfo("/proc/meminfo");
// Reads "MemAvailable:" for free RAM
// Reads "MemTotal:" for total RAM
```

The GUI displays accurate memory information to help you size your solves appropriately.

---

## Differences from macOS Build

| Aspect | macOS | Ubuntu Linux |
|--------|-------|--------------|
| **Font** | Helvetica Neue | DejaVu Sans |
| **Memory API** | `mach/vm_statistics.h` | `/proc/meminfo` |
| **GUI Framework** | FLTK with Cocoa | FLTK with X11 |
| **TBB Linking** | Static | Dynamic |
| **FLTK Version** | Homebrew 1.4.4 | Source build 1.4.4 |
| **Package Manager** | Homebrew | APT |

Code behavior is identical - only system integration differs.

---

## Web Interface Setup

To use the web interface on Ubuntu:

1. **Build json_solver** (done by default):
   ```bash
   ./build/json_solver
   ```

2. **Install Flask** (Python web framework):
   ```bash
   sudo apt install python3 python3-pip
   pip3 install flask flask-cors
   ```

3. **Run the web interface**:
   ```bash
   cd web
   python3 server.py
   ```

4. **Access in browser**: `http://localhost:5000`

See [WEB_INTERFACE_QUICK_START.md](WEB_INTERFACE_QUICK_START.md) for details.

---

## Uninstallation

To remove Shark and FLTK:

```bash
# Remove Shark build
cd ~/shark-3.0
rm -rf build

# Remove FLTK (if you want to uninstall it)
sudo rm -rf /usr/local/lib/libfltk*
sudo rm -rf /usr/local/include/FL
sudo rm -rf /usr/local/bin/fltk-config

# Remove dependencies (optional)
sudo apt remove libtbb-dev libfltk1.3-dev
sudo apt autoremove
```

---

## Getting Help

- **Build Issues:** Check troubleshooting section above
- **Usage Questions:** See main [README.md](README.md)
- **Bug Reports:** Open an issue on GitHub
- **Performance:** Check memory requirements match your use case

---

## Additional Resources

- [FLTK Documentation](https://www.fltk.org/documentation.php)
- [Intel TBB Documentation](https://www.intel.com/content/www/us/en/developer/tools/oneapi/onetbb.html)
- [CFR+ Algorithm Paper](https://arxiv.org/abs/1407.5042)
- [Pruning Implementation Details](PRUNING_IMPLEMENTATION.md)
- [Web Interface Setup](WEB_INTERFACE_QUICK_START.md)

---

## Contributing

If you encounter issues specific to Ubuntu or Linux distributions:

1. Check if your Ubuntu version is supported (20.04+)
2. Verify all dependencies are installed
3. Try the automated build script first
4. Report the issue with:
   - Ubuntu version (`lsb_release -a`)
   - Build error output
   - `ldd build/shark` output

Pull requests to improve Ubuntu compatibility are welcome!
