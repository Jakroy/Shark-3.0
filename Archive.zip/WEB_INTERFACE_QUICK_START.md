# Shark GTO Solver - Web Interface Quick Start

## What You Get

A complete web-based GTO solver interface with:

- ✅ Visual range selector (click hands on a grid)
- ✅ Board card selector (visual card picker)
- ✅ Strategy visualization (action frequencies, EV, exploitability)
- ✅ Modern, responsive UI
- ✅ RESTful API for programmatic access

## Quick Start (3 Steps)

### Option 1: Automated Setup (Recommended)

```bash
cd web
./setup.sh
python3 server.py
```

Then open http://localhost:5000 in your browser.

### Option 2: Manual Setup

#### Step 1: Build the JSON Solver

```bash
cd /Users/ajyork/Desktop/shark-2.0
mkdir -p build && cd build
cmake ..
make json_solver
```

#### Step 2: Install Python Dependencies

```bash
cd ../web
pip3 install -r requirements.txt
```

#### Step 3: Start the Server

```bash
python3 server.py
```

Open http://localhost:5000 in your browser.

## Using the Web Interface

1. **Select Board**: Click 3-5 cards for flop/turn/river
2. **Set Ranges**:
   - Use text input: `AA,KK,QQ,AKs,AKo`
   - Or click "Grid" for visual selector
3. **Configure**:
   - Stack: 100 (default)
   - Pot: 10 (default)
   - Position: IP/OOP
   - Iterations: 100 (more = better accuracy)
   - Threads: 4 (set to your CPU core count)
4. **Solve**: Click the big Solve button
5. **View Results**: See exploitability and optimal strategies

## Example Scenarios

### Standard Button vs Big Blind (Flop)

- **Board**: Ks Qh 7d
- **Hero**: `55+,A2s+,K7s+,Q8s+,J8s+,T8s+,97s+,87s,76s,A9o+,KTo+,QJo`
- **Villain**: `33+,A2s+,K2s+,Q5s+,J7s+,T7s+,96s+,85s+,75s+,64s+,A5o+,K9o+,Q9o+,J9o+,T9o`
- **Stack**: 100
- **Pot**: 10
- **Position**: 2 (OOP)
- **Iterations**: 100

### Tight Range (Fast Test)

- **Board**: As Kh 7d
- **Hero**: `AA,KK,QQ`
- **Villain**: `JJ,TT,99`
- **Stack**: 100
- **Pot**: 10
- **Iterations**: 50

## Architecture

```
┌─────────────────┐
│   Web Browser   │  (HTML/CSS/JS)
│  localhost:5000 │
└────────┬────────┘
         │ HTTP API
         ↓
┌─────────────────┐
│  Flask Server   │  (Python)
│    server.py    │
└────────┬────────┘
         │ stdin/stdout
         ↓
┌─────────────────┐
│  JSON Solver    │  (C++)
│ json_solver.cpp │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│  Shark Solver   │
│  DCFR Engine    │
└─────────────────┘
```

## Files Created

```
web/
├── index.html          ← Web UI (range selector, board selector)
├── style.css           ← Modern styling
├── app.js              ← JavaScript logic
├── server.py           ← Flask backend API
├── requirements.txt    ← Python dependencies
├── setup.sh            ← Automated setup script
└── README.md           ← Full documentation

src/cli/
└── json_solver.cpp     ← JSON CLI interface for solver

include/nlohmann/
└── json.hpp            ← JSON library (already downloaded)
```

## API Usage (Optional)

You can also use the solver programmatically:

```bash
curl -X POST http://localhost:5000/api/solve \
  -H "Content-Type: application/json" \
  -d '{
    "hero_range": "AA,KK,QQ",
    "villain_range": "JJ,TT,99",
    "board": ["As", "Kh", "7d"],
    "stack": 100,
    "pot": 10,
    "iterations": 50
  }'
```

## Performance Tips

- **Start small**: Use tighter ranges for testing (faster solves)
- **Increase threads**: Set to your CPU core count
- **Iterations**: 50-100 for testing, 500+ for production
- **Flop solving**: 5-30 seconds typical
- **Turn solving**: 30-120 seconds typical
- **River solving**: 2-10 minutes typical

## Troubleshooting

### Solver not found
```bash
cd build && make json_solver
```

### Server won't start
```bash
pip3 install Flask flask-cors
```

### Port already in use
Edit `server.py` line 99:
```python
app.run(debug=True, host='0.0.0.0', port=8080)  # Changed from 5000
```

## Next Steps

1. Try the example scenarios above
2. Experiment with different ranges
3. Compare exploitability at different iteration counts
4. Save your favorite scenarios in range strings
5. Use the API to automate batch solves

## Documentation

- Full web interface docs: `web/README.md`
- Solver optimization docs: `dcfr_optimization_summary.html`
- Main project README: `README.md`

Enjoy your new GTO solver interface! 🦈
