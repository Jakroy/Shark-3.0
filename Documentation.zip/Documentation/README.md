# Documentation

## [Algorithm](Algorithm.md)

The documentation of the underlying algorithm of the poker hand evaluator.
